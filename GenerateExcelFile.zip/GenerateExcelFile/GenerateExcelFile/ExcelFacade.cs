﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;

namespace CreateExcelFile
{
    public class ExcelFacade
    {

        /// <summary>
        /// Write excel file of a list of object as T
        /// Assume that maximum of 24 columns 
        /// </summary>
        /// <typeparam name="T">Object type to pass in</typeparam>
        /// <param name="fileName">Full path of the file name of excel spreadsheet</param>
        /// <param name="objects">list of the object type</param>
        /// <param name="sheetName">Sheet names of Excel File</param>
        /// <param name="headerNames">Header names of the object</param>
        /// 

            public void Create<T>(
            string fileName,
            List<T> objects,
            string sheetName,
            List<string> headerNames,
            string timeFormat)
        {
            //Open the copied template workbook. 
            using (SpreadsheetDocument myWorkbook = SpreadsheetDocument.Create(fileName, SpreadsheetDocumentType.Workbook))
            {
                WorkbookPart workbookPart = myWorkbook.AddWorkbookPart();
                WorksheetPart worksheetPart = workbookPart.AddNewPart<WorksheetPart>();

                // Create Styles and Insert into Workbook
                WorkbookStylesPart stylesPart = myWorkbook.WorkbookPart.AddNewPart<WorkbookStylesPart>();
                Stylesheet styles = new CustomStylesheet();
                styles.Save(stylesPart);

                string relId = workbookPart.GetIdOfPart(worksheetPart);

                Workbook workbook = new Workbook();
                FileVersion fileVersion = new FileVersion { ApplicationName = "Microsoft Office Excel" };
                
                SheetData sheetData = CreateSheetData<T>(objects, headerNames, stylesPart, timeFormat);                
                Worksheet worksheet = new Worksheet();

                int numCols = headerNames.Count;
                int width = headerNames.Max(h => h.Length) + 10;

                Columns columns = new Columns();
                for (int col = 0; col < numCols; col++)
                {
                    if(col==0)
                    {
                        width = 20;
                    }
                    else if(col ==1)
                    {
                        width = 30;
                    }
                    else if (col == 2)
                    {
                        width = 50;
                    }
                    else if (col == 3)
                    {
                        width = 72;
                    }
                    else if (col == 4)
                    {
                        width = 15;
                    }
                    else if (col == 5)
                    {
                        width = 12;
                    }
                    else if (col == 6)
                    {
                        width = 15;
                    }
                    else if (col == 7)
                    {
                        width = 12;
                    }
                    else if (col == 8)
                    {
                        width = 15;
                    }
                    Column c = CreateColumnData((UInt32)col + 1, (UInt32)numCols + 1, width);
                   
                    columns.AppendChild(c);
                }
                worksheet.Append(columns);

                Sheets sheets = new Sheets();
                Sheet sheet = new Sheet { Name = sheetName, SheetId = 1, Id = relId };
                
                sheets.Append(sheet);
                workbook.Append(fileVersion);
                workbook.Append(sheets);                
                worksheet.Append(sheetData);
                worksheetPart.Worksheet = worksheet;
                worksheetPart.Worksheet.Save();


                myWorkbook.WorkbookPart.Workbook = workbook;
                myWorkbook.WorkbookPart.Workbook.Save();
                myWorkbook.Close();
            }
        }
        private SheetData CreateSheetData<T>(List<T> objects, List<string> headerNames, WorkbookStylesPart stylesPart,string timeformat)
        {
            SheetData sheetData = new SheetData();

            if (objects != null)
            {
                //Fields names of object
                List<string> fields = GetPropertyInfo<T>();

                var az1 = new List<Char>(Enumerable.Range('A', 1).Select(i => (Char)i).ToArray());
                List<Char> headers1 = az1.GetRange(0, 1);
                var az2 = new List<Char>(Enumerable.Range('A', 1).Select(i => (Char)i).ToArray());
                List<Char> headers2 = az1.GetRange(0, 1);

                var az = new List<Char>(Enumerable.Range('A', 'Z' - 'A' + 1).Select(i => (Char) i).ToArray());
                List<Char> headers = az.GetRange(0, fields.Count);
                
                int numRows = objects.Count;
                int numCols = fields.Count;
                Row header = new Row {
                    CustomHeight = true,
                    Height=30                
                };
                Row header1 = new Row
                {
                    CustomHeight = true,
                    Height = 35
                };
                Row header2 = new Row
                {
                    CustomHeight = true,
                    Height = 20
                };


                Row header3 = new Row
                {
                    CustomHeight = true,
                    Height = 20
                    
                    
                };


                Row header4 = new Row
                {
                    CustomHeight = true,
                    Height = 20
                };


                int index1 = 1;
                header1.RowIndex = (uint)index1;

                for (int col = 0; col < 1; col++)
                {
                    //Cell c = CreateHeaderCell(headers[col].ToString(), headerNames[col], index, stylesPart.Stylesheet);
                    HeaderCell c1 = new HeaderCell("D", "OneVision EDI File Process counts ", index1, stylesPart.Stylesheet, System.Drawing.Color.SkyBlue, 18, true);
                    header1.AppendChild(c1);

                }

                sheetData.Append(header1);
                int index2 = 2;
                header2.RowIndex = (uint)index2;

                for (int col = 0; col < 1; col++)
                {
                    //Cell c = CreateHeaderCell(headers[col].ToString(), headerNames[col], index, stylesPart.Stylesheet);

                    HeaderCell c1 = new HeaderCell(headers2[col].ToString(), @"Date\Time", index2, stylesPart.Stylesheet, System.Drawing.Color.SkyBlue, 12, true);
                    header2.AppendChild(c1);

                    for (int i = 0; i < 1; i++)
                    {
                        String sDate = DateTime.UtcNow.ToString();
                        DateTime datevalue = (Convert.ToDateTime(sDate.ToString()));

                        string min = datevalue.Minute.ToString();
                        string sec = datevalue.Second.ToString();
                        string hours = datevalue.Hour.ToString();
                        string dateTimeValue = datevalue.ToShortDateString() + @"\" + timeformat;
                        var obj1 = dateTimeValue;
                        var r = new Row { RowIndex = (uint)index2 };

                        object obj = obj1;

                        if (obj != null)
                        {

                                long value;
                                if (long.TryParse(obj.ToString(), out value))
                                {
                                    //Cell c = CreateIntegerCell(headers[col].ToString(), obj.ToString(), index);
                                    NumberCell c = new NumberCell(headers[col].ToString(), obj.ToString(), index2);
                                    r.Append(c);
                                }
                                else
                                {
                                    //Cell c = CreateTextCell(headers[col].ToString(), obj.ToString(), index);
                                    TextCell c = new TextCell(headers[1].ToString(), obj.ToString(), index2);

                                    r.Append(c);
                                }
                            
                        }

                        sheetData.Append(r);

                    }

                }

                int index3 = 3;
                header3.RowIndex = (uint)index3;


                int index4 = 4;
                header4.RowIndex = (uint)index4;


                int index = 5;
                header.RowIndex = (uint)index;

                for (int col = 0; col < numCols; col++)
                {
                    HeaderCell c = new HeaderCell(headers[col].ToString(), headerNames[col], index, stylesPart.Stylesheet, System.Drawing.Color.SkyBlue, 12, true);
                    header.AppendChild(c);

                }

                sheetData.Append(header2);

                sheetData.Append(header3);

                sheetData.Append(header4);

                sheetData.Append(header);

                for (int i = 0; i < numRows; i++)
                {
                    index++;
                    var obj1 = objects[i];
                    var r = new Row { RowIndex = (uint)index };

                    for (int col = 0; col < numCols; col++)
                    {
                        string fieldName = fields[col];
                        PropertyInfo myf = obj1.GetType().GetProperty(fieldName);
                        if (myf != null)
                        {
                            object obj = myf.GetValue(obj1, null);
                            if (obj != null)
                            {
                                if (obj.GetType() == typeof(string))
                                {
                                    // Cell c = CreateTextCell(headers[col].ToString(), obj.ToString(), index);
                                    TextCell c = new TextCell(headers[col].ToString(), obj.ToString(), index);
                                    r.Append(c);
                                }
                                
                                else
                                {
                                    long value;
                                    if (long.TryParse(obj.ToString(), out value))
                                    {
                                        //Cell c = CreateIntegerCell(headers[col].ToString(), obj.ToString(), index);
                                        NumberCell c = new NumberCell(headers[col].ToString(), obj.ToString(), index);
                                        r.Append(c);
                                    }
                                    else
                                    {
                                        //Cell c = CreateTextCell(headers[col].ToString(), obj.ToString(), index);
                                        TextCell c = new TextCell(headers[col].ToString(), obj.ToString(), index);

                                        r.Append(c);
                                    }
                                }
                            }
                        }
                    }

                    sheetData.Append(r);

                }
            }

            return sheetData;
        }

        private List<string> GetPropertyInfo<T>()
        {
            
            PropertyInfo[] propertyInfos = typeof(T).GetProperties();
            // write property names
            return propertyInfos.Select(propertyInfo => propertyInfo.Name).ToList();
        }

        private Column CreateColumnData(UInt32 startColumnIndex, UInt32 endColumnIndex, double columnWidth)
        {
            Column column;
            column = new Column();
            column.Min = startColumnIndex;
            column.Max = endColumnIndex;
            column.Width = columnWidth;
            column.CustomWidth = true;
            return column;
        }

    }
}
